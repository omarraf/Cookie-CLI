/*
	Rafiq, Omar

	CS A250
	Project (Part B)
*/

#ifndef INTERFACE_H
#define INTERFACE_H


#include "CookieList.h"


void displayMenu();
void processChoice(CookieList& cookieList);


#endif

